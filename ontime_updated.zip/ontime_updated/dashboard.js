const today = startOfDay(new Date());
const STORAGE_KEY = 'ontime-plans-v2';
const PROFILE_KEY = 'ontime-profile-v1';

const defaultProfile = {
  username: 'ollie_lover',
  email: 'hello@ontime.app',
  password: 'password123'
};

const profileState = {
  ...defaultProfile,
  ...readJSON(PROFILE_KEY, {})
};

const dashboardState = {
  currentMonth: new Date(today.getFullYear(), today.getMonth(), 1),
  selectedDate: new Date(today),
  plans: loadPlans()
};

const categoryLabels = {
  friends: 'Friends',
  school: 'School',
  work: 'Work',
  family: 'Family',
  personal: 'Personal'
};

const monthLabel = document.getElementById('calendar-month-label');
const miniCalendar = document.getElementById('mini-calendar');
const selectedDayTitle = document.getElementById('selected-day-title');
const daySummary = document.getElementById('day-summary');
const dayTimeline = document.getElementById('day-timeline');
const upcomingList = document.getElementById('upcoming-list');

const profileDialog = document.getElementById('profile-dialog');
const profileForm = document.getElementById('profile-form');
const profileBtn = document.getElementById('profile-btn');
const closeProfile = document.getElementById('close-profile');
const deleteAccountBtn = document.getElementById('delete-account');

const eventDialog = document.getElementById('event-dialog');
const eventForm = document.getElementById('event-form');
const eventDialogTitle = document.getElementById('event-dialog-title');
const deleteEventBtn = document.getElementById('delete-event-btn');
const eventFormError = document.getElementById('event-form-error');

const ollieChat = document.getElementById('ollie-chat');
const chatToggle = document.getElementById('ollie-chat-toggle');
const chatWindow = document.getElementById('ollie-chat-window');
const closeChat = document.getElementById('close-chat');
const chatBody = document.getElementById('chat-body');

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function toKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function fromKey(key) {
  const [year, month, day] = key.split('-').map(Number);
  return new Date(year, month - 1, day, 12, 0, 0);
}

function shiftDate(date, days) {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
}

function makeDemoPlans() {
  const key = (days) => toKey(shiftDate(today, days));
  return {
    [key(0)]: [
      makeEvent('Coffee with Maya', key(0), '09:30', '10:30', 'friends', 'Agora Coffee', 'Catch up by the windows.'),
      makeEvent('CS study block', key(0), '14:00', '15:30', 'school', 'Library', 'Review notes and finish the practice set.')
    ],
    [key(2)]: [
      makeEvent('Walk with Noah', key(2), '18:15', '19:00', 'friends', 'Neighborhood park', 'Easy loop through the park.')
    ],
    [key(4)]: [
      makeEvent('Project check-in', key(4), '11:00', '11:45', 'work', 'Online', 'Quick progress update.')
    ],
    [key(6)]: [
      makeEvent('Family dinner', key(6), '19:00', '20:30', 'family', 'Home', 'Keep the evening open.')
    ],
    [key(-2)]: [
      makeEvent('Check-in call', key(-2), '16:00', '16:30', 'family', '', 'Quick family update.')
    ]
  };
}

function makeEvent(title, date, startTime, endTime, category = 'personal', location = '', notes = '') {
  return {
    id: createId(),
    title,
    date,
    startTime,
    endTime,
    category,
    location,
    notes
  };
}

function createId() {
  if (window.crypto?.randomUUID) return crypto.randomUUID();
  return `event-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function loadPlans() {
  const saved = readJSON(STORAGE_KEY, null);
  return saved && typeof saved === 'object' ? saved : makeDemoPlans();
}

function savePlans() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(dashboardState.plans));
}

function sameDay(a, b) {
  return a.getFullYear() === b.getFullYear()
    && a.getMonth() === b.getMonth()
    && a.getDate() === b.getDate();
}

function formatMonthLabel(date) {
  return new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' }).format(date);
}

function formatSelectedDate(date) {
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric'
  }).format(date);
}

function formatShortDate(date) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric'
  }).format(date);
}

function timeToMinutes(time) {
  const [hour, minute] = time.split(':').map(Number);
  return hour * 60 + minute;
}

function minutesToTime(minutes) {
  const normalized = ((minutes % 1440) + 1440) % 1440;
  const hour = Math.floor(normalized / 60);
  const minute = normalized % 60;
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

function formatTime(time) {
  if (!time) return '';
  const [hour, minute] = time.split(':').map(Number);
  const suffix = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${String(minute).padStart(2, '0')} ${suffix}`;
}

function getPlansFor(date) {
  return [...(dashboardState.plans[toKey(date)] || [])]
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
}

function getAllEvents() {
  return Object.values(dashboardState.plans)
    .flat()
    .sort((a, b) => {
      const dateCompare = a.date.localeCompare(b.date);
      return dateCompare || timeToMinutes(a.startTime) - timeToMinutes(b.startTime);
    });
}

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[character]));
}

function renderEverything() {
  renderMiniCalendar();
  renderDayTimeline();
  renderUpcoming();
}

function renderMiniCalendar() {
  const monthStart = new Date(dashboardState.currentMonth.getFullYear(), dashboardState.currentMonth.getMonth(), 1);
  const firstDayIndex = monthStart.getDay();
  const calendarStart = new Date(monthStart);
  calendarStart.setDate(1 - firstDayIndex);

  monthLabel.textContent = formatMonthLabel(dashboardState.currentMonth);

  const cells = [];
  for (let i = 0; i < 42; i += 1) {
    const date = new Date(calendarStart);
    date.setDate(calendarStart.getDate() + i);

    const isCurrentMonth = date.getMonth() === dashboardState.currentMonth.getMonth();
    const isToday = sameDay(date, today);
    const isSelected = sameDay(date, dashboardState.selectedDate);
    const hasPlans = getPlansFor(date).length > 0;

    const classes = ['calendar-day', isCurrentMonth ? 'in-month' : 'out-month'];
    if (isToday) classes.push('today');
    if (isSelected) classes.push('selected');
    if (hasPlans) classes.push('has-event');

    cells.push(`
      <button
        type="button"
        class="${classes.join(' ')}"
        data-date="${toKey(date)}"
        aria-label="${escapeHTML(formatSelectedDate(date))}${hasPlans ? ', has events' : ''}"
      >
        <span>${date.getDate()}</span>
        ${hasPlans ? '<span class="event-dot" aria-hidden="true"></span>' : ''}
      </button>
    `);
  }

  miniCalendar.innerHTML = cells.join('');

  miniCalendar.querySelectorAll('.calendar-day').forEach((button) => {
    button.addEventListener('click', () => {
      const nextDate = fromKey(button.dataset.date);
      dashboardState.selectedDate = nextDate;
      dashboardState.currentMonth = new Date(nextDate.getFullYear(), nextDate.getMonth(), 1);
      renderEverything();
    });
  });
}

function renderDayTimeline() {
  const plans = getPlansFor(dashboardState.selectedDate);
  selectedDayTitle.textContent = formatSelectedDate(dashboardState.selectedDate);
  daySummary.textContent = plans.length
    ? `${plans.length} ${plans.length === 1 ? 'plan' : 'plans'} · ${summarizeDayLoad(plans)}`
    : 'A clear day — there’s room for something good.';

  const startHour = 7;
  const endHour = 22;
  const rows = [];

  for (let hour = startHour; hour <= endHour; hour += 1) {
    const hourStart = hour * 60;
    const hourEnd = hourStart + 60;
    const events = plans.filter((event) => {
      const start = timeToMinutes(event.startTime);
      return start >= hourStart && start < hourEnd;
    });

    const label = formatTime(`${String(hour).padStart(2, '0')}:00`).replace(':00', '');
    rows.push(`
      <div class="timeline-row">
        <div class="timeline-time">${label}</div>
        <div class="timeline-slot">
          <span class="timeline-line" aria-hidden="true"></span>
          ${events.map(renderTimelineEvent).join('')}
        </div>
      </div>
    `);
  }

  if (!plans.length) {
    rows.splice(2, 0, `
      <div class="timeline-empty-card">
        <strong>No plans here yet.</strong>
        <span>Use “Add event” or ask Ollie where something could fit.</span>
      </div>
    `);
  }

  dayTimeline.innerHTML = rows.join('');
  dayTimeline.querySelectorAll('[data-event-id]').forEach((button) => {
    button.addEventListener('click', () => openEventDialog(button.dataset.eventId));
  });
}

function renderTimelineEvent(event) {
  const details = [event.location, event.notes].filter(Boolean).join(' · ');
  return `
    <button class="calendar-event category-${escapeHTML(event.category)}" type="button" data-event-id="${escapeHTML(event.id)}">
      <span class="calendar-event-time">${formatTime(event.startTime)}–${formatTime(event.endTime)}</span>
      <strong>${escapeHTML(event.title)}</strong>
      ${details ? `<span class="calendar-event-detail">${escapeHTML(details)}</span>` : ''}
      <span class="event-category-pill">${escapeHTML(categoryLabels[event.category] || 'Personal')}</span>
    </button>
  `;
}

function summarizeDayLoad(plans) {
  const minutes = plans.reduce((sum, event) => {
    return sum + Math.max(0, timeToMinutes(event.endTime) - timeToMinutes(event.startTime));
  }, 0);
  if (minutes >= 300 || plans.length >= 5) return 'a full day';
  if (minutes >= 150 || plans.length >= 3) return 'a balanced day';
  return 'plenty of breathing room';
}

function renderUpcoming() {
  const todayKey = toKey(today);
  const upcoming = getAllEvents()
    .filter((event) => event.date >= todayKey)
    .slice(0, 6);

  if (!upcoming.length) {
    upcomingList.innerHTML = '<p class="upcoming-empty">No upcoming plans yet.</p>';
    return;
  }

  upcomingList.innerHTML = upcoming.map((event) => `
    <button class="upcoming-event" type="button" data-upcoming-date="${event.date}" data-upcoming-id="${event.id}">
      <span class="upcoming-date">${escapeHTML(formatShortDate(fromKey(event.date)))}</span>
      <span class="upcoming-copy">
        <strong>${escapeHTML(event.title)}</strong>
        <span>${formatTime(event.startTime)}${event.location ? ` · ${escapeHTML(event.location)}` : ''}</span>
      </span>
    </button>
  `).join('');

  upcomingList.querySelectorAll('.upcoming-event').forEach((button) => {
    button.addEventListener('click', () => {
      const date = fromKey(button.dataset.upcomingDate);
      dashboardState.selectedDate = date;
      dashboardState.currentMonth = new Date(date.getFullYear(), date.getMonth(), 1);
      renderEverything();
      openEventDialog(button.dataset.upcomingId);
    });
  });
}

function setSelectedDate(date) {
  dashboardState.selectedDate = startOfDay(date);
  dashboardState.currentMonth = new Date(date.getFullYear(), date.getMonth(), 1);
  renderEverything();
}

function openEventDialog(eventId = null) {
  eventForm.reset();
  eventFormError.textContent = '';
  document.getElementById('event-id').value = '';
  deleteEventBtn.classList.add('hidden');

  const defaultDate = toKey(dashboardState.selectedDate);
  document.getElementById('event-date').value = defaultDate;
  document.getElementById('event-start').value = '18:00';
  document.getElementById('event-end').value = '19:00';
  document.getElementById('event-category').value = 'friends';
  eventDialogTitle.textContent = 'Add an event';

  if (eventId) {
    const event = findEventById(eventId);
    if (!event) return;
    eventDialogTitle.textContent = 'Edit event';
    document.getElementById('event-id').value = event.id;
    document.getElementById('event-title').value = event.title;
    document.getElementById('event-date').value = event.date;
    document.getElementById('event-start').value = event.startTime;
    document.getElementById('event-end').value = event.endTime;
    document.getElementById('event-category').value = event.category;
    document.getElementById('event-location').value = event.location || '';
    document.getElementById('event-notes').value = event.notes || '';
    deleteEventBtn.classList.remove('hidden');
  }

  eventDialog.showModal();
  requestAnimationFrame(() => document.getElementById('event-title').focus());
}

function closeEventDialog() {
  eventDialog.close();
}

function handleEventSubmit(event) {
  event.preventDefault();

  const id = document.getElementById('event-id').value;
  const title = document.getElementById('event-title').value.trim();
  const date = document.getElementById('event-date').value;
  const startTime = document.getElementById('event-start').value;
  const endTime = document.getElementById('event-end').value;
  const category = document.getElementById('event-category').value;
  const location = document.getElementById('event-location').value.trim();
  const notes = document.getElementById('event-notes').value.trim();

  if (!title || !date || !startTime || !endTime) {
    eventFormError.textContent = 'Add a name, date, start time, and end time.';
    return;
  }

  if (timeToMinutes(endTime) <= timeToMinutes(startTime)) {
    eventFormError.textContent = 'The end time needs to be after the start time.';
    return;
  }

  if (id) removeEventById(id, false);

  const nextEvent = {
    id: id || createId(),
    title,
    date,
    startTime,
    endTime,
    category,
    location,
    notes
  };

  if (!dashboardState.plans[date]) dashboardState.plans[date] = [];
  dashboardState.plans[date].push(nextEvent);
  savePlans();

  const selected = fromKey(date);
  dashboardState.selectedDate = selected;
  dashboardState.currentMonth = new Date(selected.getFullYear(), selected.getMonth(), 1);
  closeEventDialog();
  renderEverything();
}

function findEventById(id) {
  return getAllEvents().find((event) => event.id === id);
}

function removeEventById(id, rerender = true) {
  Object.keys(dashboardState.plans).forEach((dateKey) => {
    dashboardState.plans[dateKey] = dashboardState.plans[dateKey].filter((event) => event.id !== id);
    if (!dashboardState.plans[dateKey].length) delete dashboardState.plans[dateKey];
  });
  savePlans();
  if (rerender) renderEverything();
}

function deleteCurrentEvent() {
  const id = document.getElementById('event-id').value;
  if (!id) return;
  removeEventById(id, false);
  closeEventDialog();
  renderEverything();
}

function openProfileDialog() {
  document.getElementById('profile-username').value = profileState.username;
  document.getElementById('profile-email').value = profileState.email;
  document.getElementById('profile-password').value = profileState.password;
  profileDialog.showModal();
}

function closeProfileDialog() {
  profileDialog.close();
}

function deleteAccount() {
  localStorage.removeItem(PROFILE_KEY);
  localStorage.removeItem(STORAGE_KEY);
  profileDialog.close();
  alert('Your demo account and saved demo events were cleared.');
  window.location.href = 'login.html';
}

function bindProfileForm() {
  profileForm.addEventListener('submit', (event) => {
    event.preventDefault();
    profileState.username = document.getElementById('profile-username').value.trim() || profileState.username;
    profileState.email = document.getElementById('profile-email').value.trim() || profileState.email;
    profileState.password = document.getElementById('profile-password').value || profileState.password;
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profileState));
    closeProfileDialog();
  });
}

function toggleChat(forceState) {
  const isOpen = typeof forceState === 'boolean'
    ? forceState
    : chatWindow.classList.contains('hidden');
  chatWindow.classList.toggle('hidden', !isOpen);
  if (isOpen) document.getElementById('chat-input').focus();
}

function appendChatMessage(text, type) {
  const message = document.createElement('div');
  message.className = `chat-message ${type}`;
  message.textContent = text;
  chatBody.appendChild(message);
  chatBody.scrollTop = chatBody.scrollHeight;
}

function handleChatSubmit(event) {
  event.preventDefault();
  const input = document.getElementById('chat-input');
  const message = input.value.trim();
  if (!message) return;

  appendChatMessage(message, 'user');
  appendChatMessage(getOllieResponse(message), 'assistant');
  input.value = '';
}

function getOllieResponse(message) {
  const text = message.toLowerCase();
  const selectedPlans = getPlansFor(dashboardState.selectedDate);

  if (/\b(today|today's|todays)\b/.test(text)) {
    const plans = getPlansFor(today);
    if (!plans.length) return 'Today is wide open. You do not have any events on the calendar yet.';
    return `You have ${plans.length} ${plans.length === 1 ? 'plan' : 'plans'} today: ${plans.map((event) => `${event.title} at ${formatTime(event.startTime)}`).join(', ')}.`;
  }

  if (/\b(free|available|open|gap)\b/.test(text)) {
    const windows = findFreeWindows(dashboardState.selectedDate, 9 * 60, 21 * 60, 45);
    if (!windows.length) return `${formatSelectedDate(dashboardState.selectedDate)} is pretty packed between 9 AM and 9 PM.`;
    const firstThree = windows.slice(0, 3).map((window) => `${formatTime(minutesToTime(window.start))}–${formatTime(minutesToTime(window.end))}`);
    return `For ${formatSelectedDate(dashboardState.selectedDate)}, your clearest openings are ${firstThree.join(', ')}.`;
  }

  if (/\b(busy|week|packed|schedule)\b/.test(text)) {
    const days = Array.from({ length: 7 }, (_, index) => shiftDate(today, index));
    const loads = days.map((date) => ({ date, count: getPlansFor(date).length }));
    const busiest = loads.reduce((best, item) => item.count > best.count ? item : best, loads[0]);
    const quietest = loads.reduce((best, item) => item.count < best.count ? item : best, loads[0]);
    if (!busiest.count) return 'Your next seven days are completely open right now.';
    return `Over the next seven days, ${formatSelectedDate(busiest.date)} is busiest with ${busiest.count} ${busiest.count === 1 ? 'plan' : 'plans'}. ${formatSelectedDate(quietest.date)} has the most breathing room.`;
  }

  if (/\b(selected|this day|that day)\b/.test(text)) {
    if (!selectedPlans.length) return `${formatSelectedDate(dashboardState.selectedDate)} is open.`;
    return `${formatSelectedDate(dashboardState.selectedDate)} has ${selectedPlans.length} ${selectedPlans.length === 1 ? 'event' : 'events'}: ${selectedPlans.map((event) => event.title).join(', ')}.`;
  }

  if (/\b(add|create|new event|plan)\b/.test(text)) {
    return 'Use the “+ Add event” button and I’ll keep it on this calendar. You can click any event later to edit or delete it.';
  }

  return 'I can help with your calendar. Try asking “When am I free?”, “What do I have today?”, or “How busy is my week?”';
}

function findFreeWindows(date, dayStart, dayEnd, minimumMinutes) {
  const plans = getPlansFor(date)
    .map((event) => ({ start: timeToMinutes(event.startTime), end: timeToMinutes(event.endTime) }))
    .filter((event) => event.end > dayStart && event.start < dayEnd)
    .sort((a, b) => a.start - b.start);

  const windows = [];
  let cursor = dayStart;

  plans.forEach((event) => {
    const start = Math.max(event.start, dayStart);
    const end = Math.min(event.end, dayEnd);
    if (start - cursor >= minimumMinutes) windows.push({ start: cursor, end: start });
    cursor = Math.max(cursor, end);
  });

  if (dayEnd - cursor >= minimumMinutes) windows.push({ start: cursor, end: dayEnd });
  return windows;
}

function bindDialogBackdrop(dialog, closeFn) {
  dialog.addEventListener('click', (event) => {
    const rect = dialog.getBoundingClientRect();
    const inside = event.clientX >= rect.left && event.clientX <= rect.right
      && event.clientY >= rect.top && event.clientY <= rect.bottom;
    if (!inside) closeFn();
  });
}

document.getElementById('prev-month').addEventListener('click', () => {
  dashboardState.currentMonth = new Date(dashboardState.currentMonth.getFullYear(), dashboardState.currentMonth.getMonth() - 1, 1);
  renderMiniCalendar();
});

document.getElementById('next-month').addEventListener('click', () => {
  dashboardState.currentMonth = new Date(dashboardState.currentMonth.getFullYear(), dashboardState.currentMonth.getMonth() + 1, 1);
  renderMiniCalendar();
});

document.getElementById('today-btn').addEventListener('click', () => setSelectedDate(today));
document.getElementById('add-event-btn').addEventListener('click', () => openEventDialog());
document.getElementById('mobile-add-event-btn').addEventListener('click', () => openEventDialog());

document.getElementById('close-event-dialog').addEventListener('click', closeEventDialog);
document.getElementById('cancel-event-btn').addEventListener('click', closeEventDialog);
deleteEventBtn.addEventListener('click', deleteCurrentEvent);
eventForm.addEventListener('submit', handleEventSubmit);

profileBtn.addEventListener('click', openProfileDialog);
closeProfile.addEventListener('click', closeProfileDialog);
deleteAccountBtn.addEventListener('click', deleteAccount);

chatToggle.addEventListener('click', () => toggleChat());
closeChat.addEventListener('click', () => toggleChat(false));
document.getElementById('chat-form').addEventListener('submit', handleChatSubmit);

bindProfileForm();
bindDialogBackdrop(eventDialog, closeEventDialog);
bindDialogBackdrop(profileDialog, closeProfileDialog);
renderEverything();
